import './RightHero.css'

const RightHero = () => {
  return (
    <div className="RightContainer">
      
    </div>
  )
}

export default RightHero;